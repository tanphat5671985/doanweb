<?php
    session_start();
    if (!isset($_SESSION['user'])) {
        header('Location: login.php');
        exit();
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Google Classroom</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="main.js" ></script>
</head>
<body class="a">
    <nav class="navbar navbar-expand-md bg-dark navbar-dark fixed-top">     
        <a class="navbar-brand" href="classlist.php">Class</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="authorize.php">Authorization</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="classlist.php">Class List</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">Class</a>
                    <div class="dropdown-menu">
                    
                    <a class="dropdown-item" href="index.php?page_layout=add">Create class</a>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div> 
    </nav>

    <div class="container-fluid" id="u">
        <h1>List class</h1>
        <div class="row">
			<div class="col-md-6 col-md-offset-3">
                <label for="">Search class</label>
				<input type="text" class="timkiem form-control" name="" value="">
			</div>
		</div>
        <div class="row1">
            <?php
                $host = "localhost";
                $user = "root";
                $pass = "";
                $database = "database";
                $ketnoi = new mysqli($host,$user,$pass,$database);
                mysqli_set_charset($ketnoi,"utf8");
                if($ketnoi->connect_error){
                    die("".$ketnoi->connect_error);
                }else{
                    echo "";
                }
                
                $truyvan = "SELECT * FROM `lophoc`";
                $data = mysqli_query($ketnoi,$truyvan);
                                    
                while($row = mysqli_fetch_assoc($data)){
            ?>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12">
                    <div class="cell">
                        <img id="v" src="img/a.jpg"/>
                        <div class="user-info">
                            <a href="classes.php">
                                <p class="title"><?php echo "".$row["tenlop"]; ?></p>
                                <p class="subject"><?php echo "".$row["monhoc"]; ?></p>
                            </a>
                            <p class="gv"><?php echo "".$row["usernamegv"]; ?></p>
                            <p class="room"><?php echo "".$row["phonghoc"]; ?></p>
                        </div>
						<a href="index.php?page_layout=edit&id=<?php echo $row['id']?>">Edit</a>
						<a onclick="return Del('<?php echo $row['tenlop']; ?>')" href="index.php?page_layout=delete&id=<?php echo $row['id']?>">Delete</a>
                    </div>
                </div>
            <?php
                }			
            ?>  
			
        </div>
    </div>
</body>
</html>

<script>
	$('.timkiem').keyup(function(){
		var txt = $('.timkiem').val();
		$.post('ajax.php', {data: txt}, function(data){
        $('.row1').html(data);
		})
	})
</script>