<?php
    session_start();
    if (isset($_SESSION['user'])) {
        header('Location: index.php');
        exit();
    }

    require_once('db.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Google Classroom</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="style.css"/>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</head>
<body>
<?php
	$error = '';
    $email = '';
  
    if (isset($_POST['email']))
    {
		
       
        
        $email = $_POST['email'];
        
        
        if (empty($email)) {
            $error = 'Please enter your email';
        }
        else if (filter_var($email, FILTER_VALIDATE_EMAIL) == false) {
            $error = 'This is not a valid email address';
        }
        
        else {
            // register a new account
			$result = reset_pass($email);
			if ($resutl=1){
				$error='Email is not exit';
			}
			$error='You recived a reset email';
		}
    }
?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-5 col-lg-6 col-md-8 border my-5 p-4 rounded mx-3">
                <h3 class="text-center text-secondary mt-2 mb-3 mb-3">Reset your password</h3>
                <form method="post" action="" novalidate>
                    
					<div class="form-group">
                        <label for="email">Enter your email</label>
                        <input  value="<?= $email?>" name="email" required class="form-control" type="text" placeholder="Enter your email" id="email">
                    </div>
                    <div class="form-group">
                        <?php
                            if (!empty($error)) {
                                echo "<div class='alert alert-danger'>$error</div>";
                            }
                        ?>
                        <button type="submit" class="btn btn-success px-5 mt-3 mr-2">Reset pass</button>				                 
                    </div>
					
					<div class="form-group">
                        <p>Return to <a href="login.php">Login</a> page.</p>
                    </div>
                   
                </form>
                                
            </div>
        </div>

    </div>
</body>
</html>