function Del_nf(name){
	return confirm("Ban co muon xoa thong bao "+name+"?");
   }
function create_cmt(){
    location.href='comment.php';
}


function Del_nf1(name){
	return confirm("Ban co muon xoa thong bao "+name+"?");
}
function create_cmt1(){
    location.href='comment1.php';
}

function add_cmt(){
        location.href='comment.php';
    }

$(document).ready(function(){
 $('#comment_form').on('submit', function(event){
  event.preventDefault();
  var form_data = $(this).serialize();
  $.ajax({
   url:"add_comment.php",
   method:"POST",
   data:form_data,
   dataType:"JSON",
   success:function(data)
   {
    if(data.error != '')
    {
     $('#comment_form')[0].reset();
     $('#comment_message').html(data.error);
     $('#comment_id').val('0');
     load_comment();
    }
   }
  })
 });
 load_comment();
 function load_comment()
 {
  $.ajax({
   url:"fetch_comment.php",
   method:"POST",
   success:function(data)
   {
    $('#display_comment').html(data);
   }
  })
 }
 $(document).on('click', '.reply', function(){
  var comment_id = $(this).attr("id");
  $('#comment_id').val(comment_id);
  $('#comment_name').focus();
 });
});


function Dele(name){
	return confirm("Ban co muon xoa assignment "+name+"?");
}

function Del(name){
	return confirm("Ban co muon xoa lop "+name+"?");
}

$('.timkiem').keyup(function(){
	var txt = $('.timkiem').val();
	$.post('ajax.php', {data: txt}, function(data){
       $('.row1').html(data);
	})
})

let duration = 5;
let countDown = 5;
let id = setInterval(() => {

    countDown --;
    if (countDown >= 0) {
        $('#counter').html(countDown);
    }
    if (countDown == -1) {
        clearInterval(id);
        window.location.href = 'login.php';
    }

}, 1000);