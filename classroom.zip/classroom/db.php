<?php
	
	// Import PHPMailer classes into the global namespace
    // These must be at the top of your script, not inside a function
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    // Load Composer's autoloader
    require 'vendor/autoload.php';
	
	
	
	$host = "localhost";
    $user = "root";
    $pass = "";
    $database = "database";
    $ketnoi = new mysqli($host,$user,$pass,$database);
    mysqli_set_charset($ketnoi,"utf8");
    if($ketnoi->connect_error){
        die("".$ketnoi->connect_error);
    }else{
        echo "";
    }
	
	
	
    define('HOST','localhost');
    define('USER', 'root');
    define('PASS', '');
    define('DB', 'database');

   
    
    
    function open_database(){
        $conn = new mysqli(HOST,USER,PASS,DB);
        if($conn->connect_error){
            die('Connect error:'. $conn->connect_error);

        }
        //$conn->set_charsect('utf-8');
        return $conn;
    }

    function is_email_exists($email_sv){
        $sql = 'select username from hocvien where email=?';
        $conn= open_database();

        $stm= $conn->prepare($sql);
        $stm->bind_param('s',$email_sv);
        if(!$stm->execute()){
            die('Query error: '.$stm->error);
        }

        $result = $stm->get_result();
        if($result->num_rows >0){
            return true;
        }else{
            return false;
        }       

    }
    function register($ID,$user,$pass,$student_name,$birth_day,$email,$phone,$role_user){
		$conn=open_database();
        if(is_email_exists($email)){
            return array('code' => 1 , 'error'=> 'Email exists');
        }
		$hash = password_hash($pass,PASSWORD_DEFAULT);
		$sql = "insert into hocvien(id, username, password_mk, hoten, ngaysinh, email, sdt, role_user ) values (?,?,?,?,?,?,?,?)";
		$conn = open_database();
        $stm = $conn->prepare($sql);
        $stm->bind_param('ssssssss',$ID,$user,$pass,$student_name,$birth_day,$email,$phone,$role_user);// muốn ẩn mật khẩu trong database thì thay $pass = $hash

        if(!$stm->execute()){
            return array('code' => 2 , 'error'=> 'Can not execute command');
        }
        return array('code' => 0 , 'error'=> 'Create account successful');
	}
	
    function send_reset_pass($email){
        // Instantiation and passing `true` enables exceptions
		
        $mail = new PHPMailer(true);

        try {
            //Server settings
            //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      // Enable verbose debug output
            $mail->isSMTP();                                            // Send using SMTP
            $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
            $mail->Username   = 'cuong12a12018@gmail.com';                     // SMTP username
            $mail->Password   = 'fkurfyejhpjyhvqg';                               // SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
            $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

            //Recipients
            $mail->setFrom('cuong9306@gmail.com', 'Classroom');
            $mail->addAddress($email, 'Receiver');     // Add a recipient
            /*$mail->addAddress('ellen@example.com');               // Name is optional
            $mail->addReplyTo('info@example.com', 'Information');
            $mail->addCC('cc@example.com');
            $mail->addBCC('bcc@example.com');*/

            // Attachments
            //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
            //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');   // Optional name

            // Content
            $mail->isHTML(true);                                  // Set email format to HTML
            $mail->Subject = 'Reset Password';
            $mail->Body    = header('Location: reset_password.php');
            //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

            $mail->send();
            return true;
        } catch (Exception $e) {
            return false;
        }
	}
	
	function reset_pass($email){
        if(!is_email_exists($email)){
            return 1;
        }
		else {
			send_reset_pass($email);
		}
    }
	
	function new_pass($email,$pass){
		$conn=open_database();
        if(!is_email_exists($email)){
            return array('code' => 1 , 'error'=> 'Email not exists');
        }
		$hash = password_hash($pass,PASSWORD_DEFAULT);
		$query= " UPDATE `hocvien` SET passwword_mk ='$pass'";
		$conn = open_database();
        $stm = $conn->prepare($query);
        

        if(!$stm->execute()){
            return array('code' => 2 , 'error'=> 'Can not execute command');
        }
        return array('code' => 0 , 'error'=> 'Create account successful');
	}
	
?>