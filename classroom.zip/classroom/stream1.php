<?php
    session_start();
    if (!isset($_SESSION['user'])) {
        header('Location: login.php');
        exit();
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Google Classroom</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="style.css"/>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="main.js" ></script>
</head>
<body class="a">
    <nav class="navbar navbar-expand-md bg-dark navbar-dark fixed-top">
        <a class="navbar-brand" href="classes1.php">Class</a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="stream1.php">Stream</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="classwork1.php">Classwork</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="people1.php">People</a>
                </li>
            </ul>
        </div> 
		<div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="classlist1.php">List Class</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container-fluid" id="k">
		
        <div class="row1">
            <?php
                $host = "localhost";
                $user = "root";
                $pass = "";
                $database = "database";
                $ketnoi = new mysqli($host,$user,$pass,$database);
                mysqli_set_charset($ketnoi,"utf8");
                if($ketnoi->connect_error){
                    die("".$ketnoi->connect_error);
                }else{
                    echo "";
                }
                                    
                $truyvan = "SELECT * FROM `thongbao`";
                $data = mysqli_query($ketnoi,$truyvan);
                                    
                while($row = mysqli_fetch_assoc($data)){
            ?>
                <div class="col-lg-3 col-md-4 col-sm-6 col-12" id="l">
                    <div id="m" class="card">
						<div class="card-header" id="n">
							<h6 class="margin"><?php echo "By ".$row["usernamegv"]; ?></h6>
							<p class="margin"><?php echo "On ".$row["ngaydang"]; ?></p>
							<div class="dropdown" id="o">
								<button class="dropdown-toggle" data-toggle="dropdown" id="p">
								<span class="caret"></span></button>
								
							 </div>
						</div>
                        <div class="card-body" id="q">
							<p class="margin"><?php echo "".$row["tieude"]; ?></p>
							<p class="margin"><?php echo "".$row["noidung"]; ?></p>
							<a href="img/<?php echo $row['tep']; ?>"><p><?php echo "".$row['tep']; ?></p></a>
						</div>
                        <div class="card-footer">
                            
                            <form method="post" action="">
                                <button id="r" type="button" onclick="create_cmt1()" class="btn btn-primary">Comment</button>
							</form>
                        </div>
                    </div>
                </div>
            <?php
                }			
            ?>  
			
        </div>
    </div>

</body>
</html>