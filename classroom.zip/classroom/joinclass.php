<?php
    session_start();
    if (!isset($_SESSION['user'])) {
        header('Location: login.php');
        exit();
    }

    $id = $_GET['id'];
    
    if(isset($_POST['sbm'])){
        $class_id = $_POST['class_id'];


        $saveclass = "INSERT INTO class (id_lop, id_user) VALUES ('$class_id','$id')";
        $data1 = mysqli_query($ketnoi, $saveclass);
		header('location: classlist1.php');
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Google Classroom</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
</head>
<body class="a">
    <nav class="navbar navbar-expand-md bg-dark navbar-dark fixed-top">     
        <a class="navbar-brand" href="classlist1.php">Class</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav ml-auto">
                
                <li class="nav-item">
                    <a class="nav-link" href="classlist1.php">Class List</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index3.php?page_layout=join&id=<?php echo $_SESSION['user'];?>">Join class</a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div> 
    </nav>
<div class="container-fluid">
	<div class="card" id="oo">
		<div class="card-header">
			<h2>Join class</h2>
		</div>
		<div class="card-body">
			<form method="POST" enctype="multipart/form-data">
				<div class="form-group">
					<label for="">Class ID</label>
					<input type="text" name="class_id" class="form-control" required>
				</div>
				<button name="sbm" class="btn btn-success" type="submit">Join</button>
			</form>
		</div>
	</div>
</div>
   

</body>
</html>