<?php
$connect = new PDO('mysql:host=localhost;dbname=database', 'root', '');
$error = '';
$comment_name = '';
$comment_content = '';

if(empty($_POST["comment_name"]))
{
    $error .= '<p class="text-danger">Name is required</p>';
}
else
{
    $comment_name = $_POST["comment_name"];
}
if(empty($_POST["comment_content"]))
{
    $error .= '<p class="text-danger">Comment is required</p>';
}
else
{
    $comment_content = $_POST["comment_content"];
}
if($error == '')
{
    
    $takeid = "SELECT comment_id FROM binhluan";
    $takedata = mysqli_query($ketnoi, $takeid);
    $dem=0;
    while($take_up = mysqli_fetch_assoc($takedata)){
		$arrayid[$dem]=$take_up["comment_id"];
		$dem++;
    }

	$comment_id = mt_rand(1, 999);
    while(in_array($comment_id, $arrayid)){
        $comment_id = mt_rand(1, 999);
    }
    //$comment_id = mt_rand(1, 999); /////////////////random id///////////////////////
    $query = "
    INSERT INTO binhluan
    (comment_id, comment_sender_name, comment, parent_comment_id) 
    VALUES (:comment_id,:comment_sender_name, :comment, :parent_comment_id)
    ";
    $statement = $connect->prepare($query);
    $statement->execute(
    array(
        ':comment_id' =>$comment_id,
        ':comment_sender_name' => $comment_name,
        ':comment'    => $comment_content,
        ':parent_comment_id' => $_POST["comment_id"]
   
    )
);
    $error = '<label class="text-success">Comment Added</label>';
}

$data = array(
    'error'  => $error
);

echo json_encode($data);
?>