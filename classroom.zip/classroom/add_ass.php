<?php
	if(isset($_POST['sbm'])){
		$tenass = $_POST['tenass'];
		$mota = $_POST['mota'];
        $ngbatdau = date("Y-m-d H:m:s");
        $ngketthuc = $_POST['birth'];
		$usernamegv = $_POST['usernamegv'];
		
		$file_ass = $_FILES['file_ass']['name'];
		$file_ass_tmp = $_FILES['file_ass']['tmp_name'];
		
		
		$takeid = "SELECT id_ass FROM assignment";
        $takedata = mysqli_query($ketnoi, $takeid);
        $dem=0;
        while($take_up = mysqli_fetch_assoc($takedata)){
			$arrayid[$dem]=$take_up["id_ass"];
			$dem++;
        }

		$id_ass = mt_rand(1, 99);
        while(in_array($id_ass, $arrayid)){
            $id_ass = mt_rand(1, 99);
        }

		$truyvan = "INSERT INTO assignment (id_ass, tenassignment, mota, ngbatdau, ngketthuc, usernamegv, file_ass) VALUES ('$id_ass', '$tenass', '$mota', '$ngbatdau', '$ngketthuc', '$usernamegv', '$file_ass')";
		$data = mysqli_query($ketnoi, $truyvan);
		move_uploaded_file($file_ass_tmp, 'img/' .$file_ass);
		header('location: classwork.php');
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Google Classroom</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="style.css"/>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body class="a">
    <nav class="navbar navbar-expand-md bg-dark navbar-dark fixed-top">
        <a class="navbar-brand" >Teacher</a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="stream.php">Stream</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="classwork.php">Classwork</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="people.php">People</a>
                </li>
            </ul>
        </div> 
		<div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>
<div class="container-fluid">
	<div class="card" id="dd">
		<div class="card-header">
		</div>
		<div class="card-body">
			<form method="POST" enctype="multipart/form-data">
				<div class="form-group">
					<label>Name assignment</label>
					<input type="text" name="tenass" class="form-control" required>
				</div>
				<div class="form-group">
					<label>Description</label>
					<input type="text" name="mota" class="form-control" required>
				</div>
				<div class="form-group">
                    <label for="$birth_day">Deadline</label>
                    <input type="date" name="birth" class="form-control" required placeholder="Birthday" id="ngaysinhsv">
                </div>
				<div class="form-group">
                    <label for="">Choose teacher</label>
                    <select name="usernamegv" class="custom-select mb-3">
                        <?php
                            $host = "localhost";
                            $user = "root";
                            $pass = "";
                            $database = "database";
                            $ketnoi = new mysqli($host,$user,$pass,$database);
                            mysqli_set_charset($ketnoi,"utf8");
                            if($ketnoi->connect_error){
                                die("".$ketnoi->connect_error);
                            }else{
                                echo "";
                            }
                                                
                            $truyvan = "SELECT username, hoten, role_user FROM `hocvien`";
                            $data = mysqli_query($ketnoi,$truyvan);
                                                
                            while($row = mysqli_fetch_assoc($data)){
                                if($row["role_user"]==0 || $row["role_user"]==1){
                        ?>
                            <option value="<?php echo $row["username"]; ?>"><?php echo $row["hoten"]; ?></option>
                        <?php
                                }
                            }
                        ?>
                    </select>
                </div>
				<div class="form-group">
					<label for="">Attach</label>
					<input type="file" name="file_ass" class="form-control">
				</div>
				<button name="sbm" class="btn btn-success" type="submit">Post</button>
			</form>
		</div>
	</div>
</div>
</body>
</html>