<?php
	$id = $_GET['id'];
	$truyvan = "DELETE FROM assignment where id_ass = $id";
	$data = mysqli_query($ketnoi,$truyvan);
	header('location: classwork.php');
?>