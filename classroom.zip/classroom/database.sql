-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th12 02, 2020 lúc 08:40 AM
-- Phiên bản máy phục vụ: 10.4.14-MariaDB
-- Phiên bản PHP: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `database`
--
CREATE DATABASE IF NOT EXISTS `database` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `database`;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `assignment`
--

CREATE TABLE `assignment` (
  `id_ass` varchar(100) NOT NULL,
  `tenassignment` varchar(100) NOT NULL,
  `mota` longtext NOT NULL,
  `ngbatdau` datetime NOT NULL,
  `ngketthuc` datetime NOT NULL,
  `usernamegv` varchar(100) NOT NULL,
  `file_ass` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `assignment`
--

INSERT INTO `assignment` (`id_ass`, `tenassignment`, `mota`, `ngbatdau`, `ngketthuc`, `usernamegv`, `file_ass`) VALUES
('10001', 'Bài tập về nhà', 'BTVN tuần 1', '2020-10-02 22:58:46', '2020-10-03 22:58:46', 'maivanmanh', ''),
('10002', 'Bài tập lớn', 'Bài tập lớn 20% xây dựng cây AVL', '2020-10-02 22:59:47', '2020-11-11 22:59:47', 'nguyenngocphien', ''),
('10003', 'Đồ Án', 'Đề tài đồ án như file đính kèm', '2020-11-02 22:59:47', '2020-12-11 22:59:47', 'nguyenngocphien', '');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `binhluan`
--

CREATE TABLE `binhluan` (
  `comment_id` int(100) NOT NULL,
  `comment_sender_name` varchar(100) NOT NULL,
  `parent_comment_id` int(100) NOT NULL,
  `comment` mediumtext NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `binhluan`
--

INSERT INTO `binhluan` (`comment_id`, `comment_sender_name`, `parent_comment_id`, `comment`, `date`) VALUES
(1, 'huynhtanluan', 0, 'sssss', '2020-12-02 06:51:54'),
(77, 'admin', 0, 'aaaaaa', '2020-12-02 07:19:09'),
(197, 'admin', 0, 'aaaaaa', '2020-12-02 07:19:09'),
(223, 'admin', 0, 'sd', '2020-12-02 07:24:02'),
(333, 'huynhtanluan', 0, 'éa', '2020-12-02 07:19:48'),
(343, 'admin', 0, 'fvdsa', '2020-12-02 07:31:55'),
(344, 'admin', 0, 'aaaaaa', '2020-12-02 07:19:09'),
(361, 'admin', 0, 'aaaaaa', '2020-12-02 07:19:09'),
(415, 'nguyenngocphien', 0, 'aa', '2020-12-02 07:20:33'),
(416, 'admin', 0, 'aaaa', '2020-12-02 07:19:01'),
(423, 'maivanmanh', 0, 'geaivhr coadjinnbvfcdx', '2020-12-02 07:35:33'),
(528, 'admin', 0, 'aaaaaa', '2020-12-02 07:19:09'),
(537, 'admin', 10001, 'dsa', '2020-12-02 07:23:00'),
(631, 'admin', 0, 'aaaaaa', '2020-12-02 07:19:09'),
(640, 'admin', 0, 'dsa', '2020-12-02 07:13:49'),
(644, 'admin', 0, 'aaaaaa', '2020-12-02 07:19:09'),
(762, 'maivanmanh', 0, 'qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq', '2020-12-02 07:21:46'),
(764, 'maivanmanh', 0, 'qưetrhfhjkhljhgfdsa', '2020-12-02 07:25:41'),
(767, 'admin', 0, 'aaaaaa', '2020-12-02 07:19:08'),
(803, 'admin', 0, 'aaaaaa', '2020-12-02 07:19:09'),
(807, 'admin', 0, 'aaa', '2020-12-02 07:34:07'),
(1002, 'huynhtanluan', 0, 'finish', '2020-12-02 06:46:31'),
(5522, 'huynhtanluan', 0, 'gnbfdv', '2020-12-02 07:00:14'),
(10001, 'maivanmanh', 0, 'hay', '2020-12-02 17:00:00');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `class`
--

CREATE TABLE `class` (
  `id_lop` varchar(100) NOT NULL,
  `user_create` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hocvien`
--

CREATE TABLE `hocvien` (
  `id` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password_mk` varchar(100) NOT NULL,
  `hoten` text NOT NULL,
  `ngaysinh` date NOT NULL,
  `email` text NOT NULL,
  `sdt` varchar(100) NOT NULL,
  `role_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `hocvien`
--

INSERT INTO `hocvien` (`id`, `username`, `password_mk`, `hoten`, `ngaysinh`, `email`, `sdt`, `role_user`) VALUES
('90080010', 'admin', 'e10adc3949ba59abbe56e057f20f883e', 'Nguyễn Văn Admin', '2000-05-12', 'tanphat5671985@gmail.com', '0836925412', 0),
('51800434', 'huynhtanluan', 'd31d1592d76ba9b08512d82a0c643d47', 'Huỳnh Tấn Luân', '2000-06-04', 'luanhuynh92@gmail.com', '0258147369', 2),
('10020030', 'maivanmanh', 'e10adc3949ba59abbe56e057f20f883e', 'Mai Văn Mạnh', '1980-04-30', 'maivanmanh@gmail.com', '0123456789', 1),
('10020031', 'nguyenngocphien', 'c33367701511b4f6020ec61ded352059', 'Nguyễn Ngọc Phiên', '1970-04-03', 'nguyenngocphien@gmail.com', '0258369147', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `lophoc`
--

CREATE TABLE `lophoc` (
  `id` varchar(50) NOT NULL,
  `tenlop` text NOT NULL,
  `monhoc` text NOT NULL,
  `phonghoc` varchar(100) NOT NULL,
  `usernamegv` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `lophoc`
--

INSERT INTO `lophoc` (`id`, `tenlop`, `monhoc`, `phonghoc`, `usernamegv`) VALUES
('17097', '50223', 'rời rạc', 'A003', 'nguyenngocphien'),
('L001', '502001', 'Lập trình web và ứng dụng', 'B206', 'maivanmanh');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `thongbao`
--

CREATE TABLE `thongbao` (
  `id_thongbao` varchar(100) NOT NULL,
  `tieude` text NOT NULL,
  `noidung` longtext NOT NULL,
  `ngaydang` date NOT NULL,
  `usernamegv` varchar(100) NOT NULL,
  `tep` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `thongbao`
--

INSERT INTO `thongbao` (`id_thongbao`, `tieude`, `noidung`, `ngaydang`, `usernamegv`, `tep`) VALUES
('145', 'Thông báo kiểm tra', 'aaaaa', '2020-11-30', 'nguyenngocphien', 'dangnhap.php'),
('948', 'thông báo', 'nghỉ lể', '2020-11-30', 'nguyenngocphien', '');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `assignment`
--
ALTER TABLE `assignment`
  ADD PRIMARY KEY (`id_ass`),
  ADD KEY `assignment_ibfk_1` (`usernamegv`);

--
-- Chỉ mục cho bảng `binhluan`
--
ALTER TABLE `binhluan`
  ADD PRIMARY KEY (`comment_id`),
  ADD KEY `user_cmt` (`comment_sender_name`);

--
-- Chỉ mục cho bảng `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`id_lop`),
  ADD KEY `class_ibfk_2` (`user_create`);

--
-- Chỉ mục cho bảng `hocvien`
--
ALTER TABLE `hocvien`
  ADD PRIMARY KEY (`username`);

--
-- Chỉ mục cho bảng `lophoc`
--
ALTER TABLE `lophoc`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lophoc_ibfk_1` (`usernamegv`);

--
-- Chỉ mục cho bảng `thongbao`
--
ALTER TABLE `thongbao`
  ADD PRIMARY KEY (`id_thongbao`),
  ADD KEY `thongbao_ibfk_1` (`usernamegv`);

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `assignment`
--
ALTER TABLE `assignment`
  ADD CONSTRAINT `assignment_ibfk_1` FOREIGN KEY (`usernamegv`) REFERENCES `hocvien` (`username`);

--
-- Các ràng buộc cho bảng `binhluan`
--
ALTER TABLE `binhluan`
  ADD CONSTRAINT `binhluan_ibfk_2` FOREIGN KEY (`comment_sender_name`) REFERENCES `hocvien` (`username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
