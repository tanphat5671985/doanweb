<!DOCTYPE html>
<html lang="en">
<head>
  <title>Google Classroom</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="style.css"/>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="main.js" ></script>
</head>
<body class="a">
<nav class="navbar navbar-expand-md bg-dark navbar-dark fixed-top">
        <a class="navbar-brand" href="comment.php">Comment</a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="stream.php">Stream</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="classwork.php">Classwork</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="people.php">People</a>
                </li>
            </ul>
        </div> 
		<div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="classlist.php">List Class</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>
    <div class="container-fluid" id="ii">
        <form method="POST" id="comment_form">
            <div class="form-group">
                <label for="">Choose name</label>
                <select name="comment_name" class="custom-select mb-3">
                <?php
                $host = "localhost";
                $user = "root";
                $pass = "";
                $database = "database";
                $ketnoi = new mysqli($host,$user,$pass,$database);
                mysqli_set_charset($ketnoi,"utf8");
                if($ketnoi->connect_error){
                    die("".$ketnoi->connect_error);
                }else{
                    echo "";
                }
                                    
                $truyvan = "SELECT username, hoten, role_user FROM `hocvien`";
                $data = mysqli_query($ketnoi,$truyvan);
                while($row = mysqli_fetch_assoc($data)){
                ?>
                <option value="<?php echo $row["username"]; ?>"><?php echo $row["hoten"]; ?></option>
                <?php
                }
                ?>

            </div>
            <div class="form-group">
                <textarea name="comment_content" id="comment_content" class="form-control" placeholder="Enter comment" rows="5"></textarea>
            </div>
            <div class="form-group">
                <input type="hidden" name="comment_id" id="comment_id" value="0" />
                <input type="submit" onclick="add_cmt()" name="submit" id="submit" class="btn btn-info" value="Send"/>
            </div>
        </form>
        <span id="comment_message"></span>
        <br/>
        <div id="display_comment"></div>
    </div>
</body>
</html>