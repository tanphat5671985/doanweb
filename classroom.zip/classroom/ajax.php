<div class="container-fluid" id="pp">
	<div class="row">
<?php
	require_once 'db.php';
	$a = $_POST['data'];
	$truyvan = "SELECT * FROM `lophoc` where tenlop like '%$a%'";
	$data = mysqli_query($ketnoi, $truyvan);
	$num = mysqli_num_rows($data);
	if($num > 0){
		while($row = mysqli_fetch_array($data)){

?>


<div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12">
    <div class="cell">
		<img id="s" src="img/a.jpg"/>
		<div class="user-info">
			<a href="classes.php">
				<p class="title"><?php echo "".$row["tenlop"]; ?></p>
				<p class="subject"><?php echo "".$row["monhoc"]; ?></p>
			</a>
			<p class="gv"><?php echo "".$row["usernamegv"]; ?></p>
			<p class="room"><?php echo "".$row["phonghoc"]; ?></p>
		</div>
		<a href="index.php?page_layout=edit&id=<?php echo $row['id']?>">Edit</a>
		<a onclick="return Del('<?php echo $row['tenlop']; ?>')" href="index.php?page_layout=delete&id=<?php echo $row['id']?>">Delete</a>
	</div>
</div>

<?php
		}
	}
?>
	</div>
</div>