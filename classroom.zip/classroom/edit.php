<?php
	$id = $_GET['id'];
	$truyvan_up = "SELECT * FROM `lophoc` where id = $id";
	$data_up = mysqli_query($ketnoi, $truyvan_up);
	$row_up = mysqli_fetch_assoc($data_up);

	if(isset($_POST['sbm'])){
		$tenlop = $_POST['tenlop'];
		$monhoc = $_POST['monhoc'];
		$phonghoc = $_POST['phonghoc'];
		$usernamegv = $_POST['usernamegv'];
		
		$truyvan = "UPDATE lophoc SET tenlop = '$tenlop', monhoc = '$monhoc', phonghoc = '$phonghoc', usernamegv = '$usernamegv' where id = $id";
		$data = mysqli_query($ketnoi, $truyvan);
		header('location: classlist.php');
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Google Classroom</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="style.css"/>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body class="a">
	<nav class="navbar navbar-expand-md bg-dark navbar-dark fixed-top">
        <a class="navbar-brand" href="">Class</a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="authorize.php">Authorization</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="classlist.php">Class List</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">Class</a>
                    <div class="dropdown-menu">
                    <a class="dropdown-item" href="#">Join class</a>
                    <a class="dropdown-item" href="index.php?page_layout=add">Create class</a>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div> 
    </nav>
<div class="container-fluid">
	<div class="card" id="nn">
		<div class="card-header">
			<h2>Edit</h2>
		</div>
		<div class="card-body">
			<form method="POST" enctype="multipart/form-data">
				<div class="form-group">
					<label for="">Class name</label>
					<input type="text" name="tenlop" class="form-control" required value="<?php echo $row_up['tenlop']; ?>">
				</div>
				<div class="form-group">
					<label for="">Subject</label>
					<input type="text" name="monhoc" class="form-control" required value="<?php echo $row_up['monhoc'];?>">
				</div>
				<div class="form-group">
					<label for="">Room</label>
					<input type="text" name="phonghoc" class="form-control" required value="<?php echo $row_up['phonghoc'];?>">
				</div>
				<div class="form-group">
                    <label for="">Choose teacher</label>
                    <select name="usernamegv" class="custom-select mb-3">
                        <?php
                            $host = "localhost";
                            $user = "root";
                            $pass = "";
                            $database = "database";
                            $ketnoi = new mysqli($host,$user,$pass,$database);
                            mysqli_set_charset($ketnoi,"utf8");
                            if($ketnoi->connect_error){
                                die("".$ketnoi->connect_error);
                            }else{
                                echo "";
                            }
                                                
							$truyvan = "SELECT username, hoten, role_user FROM `hocvien`";
							$data = mysqli_query($ketnoi,$truyvan);
							        
                            while($row = mysqli_fetch_assoc($data)){
								if($row_up["usernamegv"]==$row["username"]){
									?>
										<option value="<?php echo $row["username"]; ?>" selected><?php echo $row["hoten"]; ?></option>
									<?php
								}else if($row["role_user"]==0 || $row["role_user"]==1){
                        ?>
                            <option value="<?php echo $row["username"]; ?>"><?php echo $row["hoten"]; ?></option>
                        <?php
								}
                            }
                        ?>
                    </select>
                </div>
				<button name="sbm" class="btn btn-success" type="submit">Edit</button>
			</form>
		</div>
	</div>
</div>
</body>
</html>
</html>