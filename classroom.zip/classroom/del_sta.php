<?php
	$id = $_GET['id'];
	$truyvan = "DELETE FROM thongbao where id_thongbao = $id";
	$data = mysqli_query($ketnoi,$truyvan);
	header('location: stream.php');
?>