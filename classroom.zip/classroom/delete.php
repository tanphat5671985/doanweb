<?php
	$id = $_GET['id'];
	$truyvan = "DELETE FROM lophoc where id = $id";
	$data = mysqli_query($ketnoi,$truyvan);
	$truyvan1 = "DELETE FROM class where id_lop = $id";
	$data1 = mysqli_query($ketnoi,$truyvan1);
	header('location: classlist.php');
?>